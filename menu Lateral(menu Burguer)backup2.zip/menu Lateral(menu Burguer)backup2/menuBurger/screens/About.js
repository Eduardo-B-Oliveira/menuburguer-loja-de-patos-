// screens/HomeScreen.js
import React from 'react';
import { View, Text } from 'react-native';
import styles from '../src/styles/AboutScreenStyles';

function AboutScreen() {
  return (
    <View style={styles.container}>
      <Text>Vendemos patos!!!</Text>
    </View>
  );
}

export default AboutScreen;