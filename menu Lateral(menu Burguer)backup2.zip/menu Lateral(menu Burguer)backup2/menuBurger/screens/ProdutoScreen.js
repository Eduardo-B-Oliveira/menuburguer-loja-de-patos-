import React from 'react';
import { View, Text, TouchableOpacity, FlatList, Image } from 'react-native';
import styles from '../src/styles/ProdutoScreenStyles';

const produtos = [
  { id: '1', nome: 'Pato Gordo', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoGezm-iD7IXBLm4LxqZkUuVcCnaH1ayUS4tJhfiYqsOwX608-5rSs2alOkj65ep4oyBQ&usqp=CAU' },
  { id: '2', nome: 'Pato Shy', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiR-kRNpbEOnw0yIyhbyHRMmSZuSygL8YEZw&s' },
  { id: '3', nome: 'Pato Assado', imagem: 'https://pubimg.band.com.br/files/1458c96aaa383bb6f1f9.png' },
  { id: '4', nome: 'Pato Amarelo', imagem: 'https://www.menudospeques.net/images/recursos_infantiles/cuentos/pato-oro.jpg' },
  { id: '5', nome: 'Pato Marrom', imagem: 'https://thumbs.dreamstime.com/b/pato-gordo-no-gelo-108739929.jpg' },
];

function ProdutoScreen() {
  const renderItem = ({ item }) => (
    <View style={styles.productItem}>
      <Image
        source={{ uri: item.imagem }}
        style={styles.productImage}
      />
      <Text style={styles.productName}>{item.nome}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Lista de Produtos</Text>

      <FlatList
        data={produtos}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
}

export default ProdutoScreen;