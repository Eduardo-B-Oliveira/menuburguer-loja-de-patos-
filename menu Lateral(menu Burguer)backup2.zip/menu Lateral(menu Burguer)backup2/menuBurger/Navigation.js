import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './screens/HomeScreen';
import SettingsScreen from './screens/SettingsScreen';
import AboutScreen from './screens/About';
import LoginScreen from './screens/LoginScreen';
import ProdutoScreen from './screens/ProdutoScreen';

const Drawer = createDrawerNavigator();

function Navigation() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Sair" >
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Settings" component={SettingsScreen} />
        <Drawer.Screen name="About" component={AboutScreen} />
        <Drawer.Screen name="Sair" component={LoginScreen} />
        <Drawer.Screen name="Produtos" component={ProdutoScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

export default Navigation;